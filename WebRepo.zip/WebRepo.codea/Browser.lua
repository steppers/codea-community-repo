-- Browser
--
-- Handles the Project browser UI
    
function draw()
    background(23, 228, 183)
    
    updateAccessToken()
end