--------------------------------------------------------------------------------
-- Requires
--------------------------------------------------------------------------------
local mime = require("mime")





--------------------------------------------------------------------------------
-- Local constants
--------------------------------------------------------------------------------
local GITHUB_USER = "steppers"
local GITHUB_REPO = "codea-community-repo"
local GITHUB_BRANCH = "main"
local GITHUB_API_URL = "https://api.github.com/repos/" .. GITHUB_USER .. "/" .. GITHUB_REPO .. "/contents/"
local GITHUB_BLOB_URL = "https://api.github.com/repos/" .. GITHUB_USER .. "/" .. GITHUB_REPO .. "/git/blobs/"

local http_params = nil
local http_params_hash = nil

function generateHTTPParams(token)
    http_params = {
        ["method"] = "GET",
        ["headers"] = {
            ["Authorization"] = "token " .. token,
            ["Accept"] = "application/vnd.github.v3+json"
        }
    }
    
    http_params_hash = {
        ["method"] = "HEAD",
        ["headers"] = {
            ["Authorization"] = "token " .. token,
            ["Accept"] = "application/vnd.github.v3+json"
        }
    }
end





--------------------------------------------------------------------------------
-- Local Variables
--------------------------------------------------------------------------------
local project_list = {}





--------------------------------------------------------------------------------
-- Private implementation
--------------------------------------------------------------------------------

-- Callback is called passing the hash of the object or nil if the request failed
-- for any reason
local function getObjSHA(path, cb)
    local function on_success(data, status, headers)
        if status == 200 then
            local sha = string.gsub(headers.Etag, "\"", "")
            sha = string.gsub(sha, "W/", "", 1)
            cb(sha)
        else
            cb(nil)
        end
    end
    
    local function on_fail(error)
        cb(nil)
    end
    
    -- Replace spaces in path with '%20'
    path = string.gsub(path, " ", "%%20")
    
    http.request(GITHUB_API_URL .. path .. "?ref=" .. GITHUB_BRANCH, on_success, on_fail, http_params_hash)
end

-- Callback is called with table containing repo directory entries, or nil if
-- the http request failed for any reason
local function getDirJson(path, cb)
    local function on_success(data, status, headers)
        if status == 200 then
            cb(json.decode(data))
        else
            cb(nil)
        end
    end
    
    local function on_fail(error)
        cb(nil)
    end
    
    -- Replace spaces in path with '%20'
    path = string.gsub(path, " ", "%%20")
    
    http.request(GITHUB_API_URL .. path .. "?ref=" .. GITHUB_BRANCH, on_success, on_fail, http_params)
end

-- Downloads data associated with the specified SHA.
-- Returned string data is base64 encoded
local function getBlob(sha, cb)
    local function on_success(data, status, headers)
        if status == 200 then
            data = json.decode(data)
            cb(data.content)
        else
            cb(nil)
        end
    end
    
    local function on_fail(error)
        cb(nil)
    end
    
    http.request(GITHUB_BLOB_URL .. sha, on_success, on_fail, http_params)
end

-- Downloads a file, regardless of the hash and does not cache the response
--
-- The callback will be called passing the file data (as a base64 encoded string)
-- if the download succeeds or nil if the request fails for any reason.
local function getFile(path, cb, hash)
    -- Retrieve the file's sha first so we can access its blob
    getObjSHA(path, function(sha)
        if sha then
            -- If we didn't pass a hash, always download.
            -- Otherwise, only download if the hash differs
            if hash == nil or sha ~= hash then
                getBlob(sha, cb)
            end
        else
            cb(nil)
        end
    end)
end

-- Downloads and caches a project recursively
local function getProject(name, cb, sha)
    
    local path = name .. ".zip"
    local project_path = name .. ".codea"
    
    -- Check if we actually need to download or update this project
    if readLocalData("sha:" .. path) == sha then
        cb(true)
        return
    end
    
    -- Download the project's zip file
    getFile(path, function(data)
        if data == nil then
            cb(false)
            return
        end
        
        data = mime.unb64(data)
        
        local files = zzlib.listzip(data)
        
        if not hasProject(name) then
            createProject(name)
        end
        
        for _,filepath in pairs(files) do
            local _, slashes = string.gsub(filepath, "/", "")
            if string.sub(filepath, -1, -1) ~= "/" and slashes == 1 then
                local file_data = zzlib.unzip(data, filepath)
                
                -- Write directly to the file
                local asset_path = asset .. "/../" .. filepath
                
                if file_data ~= nil then
                    local file = io.open(asset_path.path, "w")
                    file:write(file_data)
                    file:close()
                end
            end
        end
        
        saveLocalData("sha:" .. path, sha)
        cb(true)
    end, nil)
end





--------------------------------------------------------------------------------
-- Public API
--------------------------------------------------------------------------------

-- Initialises the WebRepo library with previously cached data
function initWebRepo(token)
    
    -- Make sure our request parameters are up to date
    generateHTTPParams(token)
    
    -- Download status.lua from the repo and run it
    getFile("status.lua", function(data)
        if data then
            local fn = load(mime.unb64(data))
            if fn then fn() else
                print("status.lua failed to load correctly!")
            end
        else
            print("Codea Web Repository is currently unavailable")
        end
    end)
    
    -- Load the project list from disk
    local pl = readLocalData("project_list")
    if pl then project_list = json.decode(pl) end
    
    -- Check Projects are still installed
    for _,proj in pairs(project_list) do
        if not hasProject(proj.name) then
            proj.installed = false
            proj.upToDate = false
            
            -- Clear hash
            saveLocalData("sha:" .. proj.path, nil)
        end
    end
end

-- Grabs the latest list of projects from the repository
-- If we are unable to connect, then this does nothing.
--
-- Callback is called if/when the update completes
function updateWebRepo(cb)
    -- Directories in the root contain projects
    getDirJson("", function(j)
        
        -- Check that we received a response
        if j == nil then
            cb() -- We tried...
            return
        end
        
        -- Iterate over the dir entries
        for _,v in pairs(j) do
            
            -- zip files contain projects
            if v.type == "file" and string.find(v.name, ".zip") ~= nil then
                
                -- Strip bundle suffix
                v.name = string.gsub(v.name, ".zip", "", 1)
                
                -- Add this project to the list
                local hash = readLocalData("sha:" .. v.path)
                project_list[v.name] = {
                    ["name"] = v.name,
                    ["path"] = v.path,
                    ["sha"] = v.sha,
                    ["installed"] = (hash ~= nil),
                    ["upToDate"] = (hash == v.sha)
                }
            end
        end
        
        -- Save the project list to disk
        saveLocalData("project_list", json.encode(project_list))
        
        -- Inform the caller that we've updated the project list
        if cb then cb() end
    end)
end

-- Downloads the specified project, or updates it if required
--
-- cb = function(success)
function downloadProject(projectName, cb)
    
    -- Nil check if the caller doesn't care
    cb = cb or function(s) end
    
    -- Is the project already fully downloaded?
    if project_list[projectName].upToDate then
        cb(true)
        return
    end
    
    -- Let the user know what's going on
    if project_list[projectName].installed then
        print("Updating " .. projectName)
    else
        print("Downloading " .. projectName)
    end
    
    -- Download the project's directory
    getProject(projectName, function(success)
        if success then
            project_list[projectName].installed = true
            cb(true)
            -- Succeed if the project was already installed
        elseif project_list[projectName].installed then
            cb(true)
        else
            print("There was a problem downloading the project. Please check your internet connection.")
            cb(false)
        end
    end, project_list[projectName].sha)
end

-- Launches the specified project (if downloaded)
function launchProject(projectName)
    if projectIsInstalled(projectName) then
        -- Clear parameters & log
        output.clear()
        parameter.clear()
        
        -- Path to the project's bundle
        local project_path = "/../" .. projectName .. ".codea/"
        
        -- Parse project Info.plist
        local plist = readText(asset .. project_path .. "Info.plist")
        if plist == nil then
            print("Unable to open Info.plist in " .. projectName)
            return
        end
        plist = parsePList(plist)
        
        -- Parse project Data.plist
        local data_plist = readText(asset .. project_path .. "Data.plist")
        if data_plist ~= nil then
            data_plist = parsePList(data_plist)
        end
        
        -- Override Codea storage APIs
        saveProjectData = function(key, value) end -- Do nothing
        readProjectData = function(key, default)
            return data_plist[key] or default
        end
        -- TODO: implement the rest
        
        -- Nil out user defined callbacks
        setup = nil
        draw = function() background(0, 0, 0) end
        --- TODO: other callbacks
        
        -- Load lua files in the project specified order
        for _,tab in ipairs(plist["Buffer Order"]) do
            local code = readText(asset .. project_path .. tab .. ".lua")
            if code == nil then
                print("Unable to load " .. tab .. ".lua in " .. projectName)
                return
            end
            
            -- Fixup asset paths so they direct to the correct project
            --
            -- NOTE: Assets used in these projects must use assets from the bundle.
            --       Assets read from elsewhere should not be assumed to exist!
            
            -- 'asset .. "/explosion"' -> 'asset .. "/../demo.codea/" .. "/explosion"'
            code = string.gsub(code, "asset *%.%. *([^,)]+)", "asset .. \"" .. project_path .. "\" .. %1")
            -- 'asset.explosion' -> 'asset .. "/../demo.codea/explosion"'
            code = string.gsub(code, "asset%.([^,)]+)", "asset .. \"" .. project_path .. "%1\"")
            -- '"Project:explosion"' -> 'asset .. "/../demo.codea/explosion"
            code = string.gsub(code, "\"Project:\"", "asset .. \"" .. project_path .. "\"")
            code = string.gsub(code, "\"Project:", "asset .. \"" .. project_path)
            
            -- Load the file
            local fn, err = load(code)
            if fn == nil then
                print(err)
                return
            end
            
            fn()
        end
        
        -- Run the loaded project's setup() function
        setup()
    end
end

-- Returns true if the specified project has an update available
-- in the repo
function projectCanBeUpdated(projectName)
    return not project_list[projectName].upToDate
end

-- Returns true if the specified project is currently downloaded
function projectIsInstalled(projectName)
    return project_list[projectName].installed
end

-- Returns table containing metadata for the specified project
function projectInfo(projectName)
    return project_list[projectName]
end

-- Returns an array of projects (installed or not)
function getProjects()
    return project_list
end
